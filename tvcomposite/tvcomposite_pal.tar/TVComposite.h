#include <IOKit/IOService.h>
#include <IOKit/pci/IOPCIDevice.h>

class TVComposite : public IOService
{
 OSDeclareDefaultStructors(TVComposite);

private:
 IOPCIDevice *nvPCIDevice;

public:
 virtual bool start(IOService *provider);
 virtual void stop(IOService *provider);
};
