#include <IOKit/IOLib.h>
#include <libkern/c++/OSMetaClass.h>

#include "TVComposite.h"

UInt32 READ_REG(UInt8 *p,int n)
{
 *((UInt32 *)(p+0x00D220)) = n;

 return *((UInt32 *)(p+0x00D224));
}

UInt32 READ_IO(UInt8 *p,UInt32 off)
{
 return *((UInt32 *)(p+off));
}

void WRITE_REG(UInt8 *p,int n,UInt32 val)
{
 *((UInt32 *)(p+0x00D220)) = n;
 *((UInt32 *)(p+0x00D224)) = val;
}

void WRITE_IO(UInt8 *p,UInt32 off,UInt32 val)
{
 *((UInt32 *)(p+off)) = val;
}

#define super IOService

OSDefineMetaClassAndStructors(TVComposite,IOService);

bool TVComposite::start(IOService *provider)
{
 IOMemoryMap *map;

 if(!super::start(provider))
  return (false);

 assert(OSDynamicCast(IOPCIDevice,provider));
 nvPCIDevice = (IOPCIDevice *) provider;

 // nvPCIDevice->setMemoryEnable(true);
 nvPCIDevice->setIOEnable(true,false);

 map = nvPCIDevice->mapDeviceMemoryWithRegister(kIOPCIConfigBaseAddress0);
 if (map)
  {
   UInt8 *p;
   p = (UInt8 *) map->getVirtualAddress();

   WRITE_REG(p,0x00,0x2A); 
   WRITE_REG(p,0x01,0x09); 
   WRITE_REG(p,0x02,0x8A); 
   WRITE_REG(p,0x03,0xCB); 
   WRITE_REG(p,0x0C,0x27); 
   if (READ_REG(p,0x34) == 0x04)
    WRITE_REG(p,0x34,0x40); 
   WRITE_REG(p,0x06,0x0B);  
   WRITE_IO(p,0x00D204,0x00010002);

   map->release();
  }
		  
 registerService();

 return (true);
}

void TVComposite::stop(IOService *provider)
{
 super::stop(provider);
}
